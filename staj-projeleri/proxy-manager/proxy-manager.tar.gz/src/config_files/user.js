user_pref("network.proxy.type", 0);
