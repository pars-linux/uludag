#!/usr/bin/python
# -*- coding: utf-8 -*-

from distutils.core import setup, Extension


setup(name="pyv4l2",
      version="1.0",
      ext_modules = [Extension('pyv4l2',
                               sources=['pyv4l2.c'],
                               libraries=['v4l2'])
                    ])