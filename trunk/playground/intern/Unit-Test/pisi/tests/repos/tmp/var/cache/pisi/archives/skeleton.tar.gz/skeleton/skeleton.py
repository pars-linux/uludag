#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# Copyright 2006 TUBITAK/UEKAE
# Licensed under the GNU General Public License, version 2.
# See the file http://www.gnu.org/copyleft/gpl.txt.

import sys
import getopt
import os

help = """%s (C) 2006 TUBITAK/UEKAE

Usage: %s [Options]

Options:
        -j  --jump              jump
        -h  --help              help
        -v  --version           version
"""

def usage():
    name = os.path.basename(sys.argv[0])
    print help % (name, name)

if len(sys.argv) > 1:
    try:
        opts, args = getopt.getopt(sys.argv[1:], "hvj", ["help", "version", "jump"])
    except getopt.GetoptError:
        usage()
        sys.exit(2)
        
    for o, a in opts:
        if o in ("-v", "--version"):
            print "Why do you ask that?"
        if o in ("-j", "--jump"):
            print "You first!"
        if o in ("-h", "--help"):
            usage()
else:
    usage()
