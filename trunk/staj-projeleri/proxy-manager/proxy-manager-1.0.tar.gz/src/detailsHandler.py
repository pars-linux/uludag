
from detailsDialog import detailsDialog
from qt import *
from kdecore import *

class detailsHandler(detailsDialog):
    def __init__(self, parent, prfl):
        detailsDialog.__init__(self, parent, modal = 1)
        
        self.prfl = prfl
        self.user.setText(self.prfl.user)
        self.passwd.setText(self.prfl.pasw)
        
        self.connect(self.ok, SIGNAL('clicked()'), self.press_ok)
        self.connect(self.cancel, SIGNAL('clicked()'), self.press_cancel)
        
        self.show()
    
    def press_ok(self):
        self.prfl.user = unicode(self.user.text())
        self.prfl.pasw = unicode(self.passwd.text())
        self.hide()
    
    def press_cancel(self):
        self.hide()
        
